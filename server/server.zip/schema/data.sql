INSERT INTO users (
  email,
  password,
  first_name,
  last_name,
  phone,
  role,
  is_active
) VALUES (
  'admin@abegarage.com',
  '@Abe.garage1',
  'Abe', 
  'Garage',
  '+25111555987', 
  'admin',
  TRUE
);
